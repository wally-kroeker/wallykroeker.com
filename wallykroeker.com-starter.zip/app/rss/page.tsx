export default function RSSPlaceholder() {
  return (
    <div className="p-8 text-zinc-300">
      RSS feed coming soon. For now, follow Cognitive Loop on Substack.
    </div>
  )
}
