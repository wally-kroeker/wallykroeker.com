export default function Colophon() {
  return (
    <div className="p-8 text-zinc-300">
      Built with Next.js + Tailwind. Content in Markdown. Deployed from an LXC via Cloudflare Tunnel.
    </div>
  )
}
