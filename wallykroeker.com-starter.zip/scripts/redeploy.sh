#!/usr/bin/env bash
set -euo pipefail
cd /home/wally/apps/wallykroeker.com
git pull
pnpm install
pnpm build
sudo systemctl restart wally-web
echo "Redeployed."
