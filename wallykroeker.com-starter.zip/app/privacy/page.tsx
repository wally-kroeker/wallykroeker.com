export default function Privacy() {
  return (
    <div className="p-8 text-zinc-300">
      This site does not use third‑party trackers. Minimal server logs for ops only.
    </div>
  )
}
